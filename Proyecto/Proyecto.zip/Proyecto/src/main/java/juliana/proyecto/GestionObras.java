package juliana.proyecto;
// Se importan las clases HashSet, Set y Serializable de Java.
import java.util.HashSet;
import java.util.Set;
import java.io.Serializable;

public class GestionObras implements Serializable {

    
    private Set<Artista> listaArtistas;
    private Set<Obra> listaObras;

    // Inicializa la lista
    public GestionObras() {
        this.listaArtistas = new HashSet<>();
        this.listaObras = new HashSet<>();
    }

    // Getters
    public Set<Artista> getListaArtistas() {
        return listaArtistas;
    }

    public Set<Obra> getListaObras() {
        return listaObras;
    }
    
    //Setters
    public void setListaArtistas(Set<Artista> listaArtistas) {
        this.listaArtistas = listaArtistas;
    }

    public void setListaObras(Set<Obra> listaObras) {
        this.listaObras = listaObras;
    }
    
    

    //Método agregarArtista para agregar un nuevo artista a listaArtistas.
    public void agregarArtista(String nombre, String fechaNac, String nacionalidad, String biografia) throws Exception {
        
        Artista nuevoArtista = encontrarArtista(nombre);

        if (nuevoArtista != null){
            throw new Exception("ERROR: El artista ya existe.");
        }
        else{
            nuevoArtista = new Artista(nombre, fechaNac, nacionalidad, biografia);  // Asume que tienes un constructor apropiado en la clase Artista
            listaArtistas.add(nuevoArtista);
        }

    }

    // Método agregarObra para agregar una nueva obra a listaObras. Este método también verifica si el artista de la obra existe.
    public void agregarObra(String titulo, String tecnica, int ano, double precio, String nombre, String dibujo) throws Exception {
        
        Obra obra = encontrarObra(titulo);

        if (obra != null) {
            throw new Exception("ERROR: La obra ya existe.");
        } else {
             
            Artista artista = encontrarArtista(nombre);

            if (artista == null) {
                throw new Exception("ERROR: El artista no existe");
            }
            else{
                listaObras.add(new Obra(titulo, tecnica, ano, precio, artista, dibujo));
            }
        }
    }

    // Método eliminarObra para eliminar una obra de listaObras.
    public void eliminarObra(String titulo) throws Exception {
        
        Obra obra = encontrarObra(titulo);

        if (obra != null) {
            listaObras.remove(obra);
        } else {
            throw new Exception("ERROR: La obra no existe.");
        }
    }

    // Método eliminarArtista para eliminar un artista de listaArtistas. También elimina las obras del artista eliminado de listaObras.
     public void eliminarArtista(String nombre) throws Exception{
        Artista artista = encontrarArtista(nombre);
        if(artista != null){
            listaArtistas.remove(artista);
            listaObras.removeIf(obra -> obra.getArtista().equals(artista));
        } else {
             throw new Exception("ERROR: El artista no existe.");
        }
    }

    // Método listarObras para devolver un conjunto de las obras de un artista especificado.
    public HashSet<Obra> listarObras(String nombreArtista) throws Exception{
        
        HashSet<Obra> obrasArtista = new HashSet<>();
        Artista artista = encontrarArtista(nombreArtista);
        if(artista != null){
            listaObras.stream()
                    .filter(obra -> obra.getArtista().equals(artista))
                    .forEach(obrasArtista::add);
        } else {
            throw new Exception("ERROR: El artista no existe.");
        }
        return obrasArtista;
    }
    
    // Método encontrarObra para encontrar una obra en listaObras por su título.
     public Obra encontrarObra(String titulo){
        return listaObras.stream()
                .filter(obra -> obra.getTitulo().equals(titulo))
                .findFirst()
                .orElse(null);    
    }
     
    // Método encontrarArtista para encontrar un artista en listaArtistas por su nombre.
    public Artista encontrarArtista(String nombre){
        return listaArtistas.stream()
                .filter(artista -> artista.getNombre().equals(nombre))
                .findFirst()
                .orElse(null);    
    }
}

