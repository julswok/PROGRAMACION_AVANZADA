package juliana.proyecto;

import java.io.*;
import java.util.Set;
import java.util.HashSet;
import java.util.Date;

public class ControlGaleria implements Serializable{
    private ControlCliente controlCliente;
    private GestionObras gestionObras;
    private Set<Compras> listaCompras;

    public ControlGaleria() {
        this.controlCliente = new ControlCliente();
        this.gestionObras = new GestionObras();
        this.listaCompras = new HashSet<>();
    }
    
    //Getters
    public ControlCliente getControlCliente() {
        return controlCliente;
    }

    public GestionObras getGestionObras() {
        return gestionObras;
    }
    
    public Set<Compras> getListaCompras() {
        return listaCompras;
    }
    
    //Setters
    public void setControlCliente(ControlCliente controlCliente) {
        this.controlCliente = controlCliente;
    }

    public void setGestionObras(GestionObras gestionObras) {
        this.gestionObras = gestionObras;
    }

    public void setListaCompras(Set<Compras> listaCompras) {
        this.listaCompras = listaCompras;
    }
    
    // El método 'realizarCompra' crea un nuevo objeto Compras con la fecha y hora actuales, la obra y el cliente proporcionados. Luego, agrega esta compra a la lista de compras.
    public Compras realizarCompra(Cliente cliente, Obra obra) {
        
        Date fechaActual = new Date(); // Obtener la fecha y hora actual

        Compras compra = new Compras(fechaActual, obra, cliente);
        
        listaCompras.add(compra);

        return compra;
    }
}

