package juliana.proyecto;

import java.util.Set;
import java.util.HashSet;
import java.io.Serializable;
import java.util.stream.Collectors;

public class ControlCliente implements Serializable {
    
    private Set<Cliente> listaClientes;

    //Inicializa la lista
    public ControlCliente() {
        this.listaClientes = new HashSet<>();
    }
    //Getter
    public Set<Cliente> getListaClientes() {
        return listaClientes;
    }
    
    //Setter
    public void setListaClientes(Set<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }
    
    
    //Método para agregar un cliente a la listaClientes.
    public void agregarCliente(String nombre, String direccion, String email) throws Exception {
        
        Cliente nuevoCliente = new Cliente(nombre, direccion, email);
        
        if (!listaClientes.add(nuevoCliente)){
            throw new Exception("ERROR: El cliente ya existe.");
        }
    }
    
    //Método para eliminar un cliente de la listaClientes.
    public void eliminarCliente(String email) throws Exception {
        
        Cliente clienteAEliminar = encontrarCliente(email);
        
        if(clienteAEliminar == null){
            throw new Exception("ERROR: El cliente no existe.");
        }
        else{
            listaClientes.remove(clienteAEliminar);
        }
    }
    
    //Método para listar las compras de un cliente específico a partir de una lista de compras proporcionada.
    public Set<Compras> listarCompras(String email, Set<Compras> listaCompras) throws Exception {
       
       Cliente cliente = encontrarCliente(email);

       if (cliente == null) {
           throw new Exception("ERROR: El cliente no existe.");
       }

       return listaCompras.stream()
                          .filter(compra -> compra.getCliente().getEmail().equals(cliente.getEmail()))
                          .collect(Collectors.toSet());
   }

    
    // Método para encontrar un cliente en la listaClientes a través de su email.
    public Cliente encontrarCliente(String email) {
        return listaClientes.stream()
                            .filter(cliente -> cliente.getEmail().equals(email))
                            .findFirst()
                            .orElse(null);
    }
}
