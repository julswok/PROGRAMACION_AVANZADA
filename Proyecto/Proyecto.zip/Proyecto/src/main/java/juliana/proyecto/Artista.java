package juliana.proyecto;

import java.io.Serializable;
import java.util.Objects;

public class Artista implements Serializable{
 
    private String nombre;
    private String fechaNac;
    private String nacionalidad;
    private String biografia;

    public Artista(String nombre, String fechaNac, String nacionalidad, String biografia) {
        this.nombre = nombre;
        this.fechaNac = fechaNac;
        this.nacionalidad = nacionalidad;
        this.biografia = biografia;
    }
    
    //Getters
    public String getNombre() {
        return nombre;
    }

    public String getFechaNac() {
        return fechaNac;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public String getBiografia() {
        return biografia;
    }
    
    //Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }
    
     // Sobreescribe el método equals para determinar si dos objetos Artista son iguales basándose en su atributo 'nombre'.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Artista artista = (Artista) o;
        return nombre.equals(artista.nombre);
    }
    
   // Sobreescribe el método hashCode para proporcionar un código hash consistente con el método equals.
    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
    
    @Override
    public String toString() {
        return nombre + ", " + fechaNac + ", " + nacionalidad + "\n Biografia: " + biografia;
    }
}

