package juliana.proyecto;


import java.io.Serializable;
import java.util.Objects;

public class Cliente implements Serializable{
    private String nombre;
    private String direccion;
    private String email;

    public Cliente(String nombre, String direccion, String email) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.email = email;
    }
    //Getters
    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getEmail() {
        return email;
    }
    //Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    // Sobreescribe el método equals para determinar si dos objetos Cliente son iguales basándose en su atributo 'email'.
     @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cliente cliente = (Cliente) o;
        return email.equals(cliente.email);
    }
    
    // Sobreescribe el método hashCode para proporcionar un código hash consistente con el método equals.
    @Override
    public int hashCode() {
        return Objects.hash(email);
    }
    
     @Override
    public String toString() {
        return nombre + ", " + direccion + ", "+ email;
    }
}
