package juliana.proyecto;

import java.io.Serializable;
import java.util.Objects;


public class Obra implements Serializable{
    
    private String titulo;
    private String tecnica;
    private int ano;
    private double precio;
    private Artista artista;
    private String dibujo;
            
    public Obra(String titulo, String tecnica, int ano, double precio, Artista artista, String dibujo) {
        this.titulo = titulo;
        this.tecnica = tecnica;
        this.ano = ano;
        this.precio = precio;
        this.artista = artista;
        this.dibujo = dibujo;
    }
    //Getters
    public String getTitulo() {
        return titulo;
    }

    public String getTecnica() {
        return tecnica;
    }

    public int getAno() {
        return ano;
    }

    public double getPrecio() {
        return precio;
    }

    public Artista getArtista() {
        return artista;
    }

    public String getDibujo() {
        return dibujo;
    }
    
    
    //Setters
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    public void setDibujo(String dibujo) {
        this.dibujo = dibujo;
    }
    
    
    // Sobreescribe el método equals para determinar si dos objetos Obra son iguales basándose en su atributo 'titulo'.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Obra obra = (Obra) o;
        return titulo.equals(obra.titulo);
    }
    
    // Sobreescribe el método hashCode para proporcionar un código hash consistente con el método equals.
    @Override
    public int hashCode() {
        return Objects.hash(titulo);
    }
    
    
    @Override
    public String toString() {
        return "\t\t" + titulo + "----\n\n"+ dibujo + "\n\n\t\t" + tecnica + "\n\t\t" + ano + "\n\t\t" + precio + "$\n\t\t" + artista.getNombre();
    }  
}
