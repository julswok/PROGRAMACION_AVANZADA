package juliana.proyecto;

import java.util.Date;
import java.io.Serializable;

public class Compras implements Serializable{
    
    private Date fecha;
    private Obra obra;
    private Cliente cliente;

    public Compras(Date fecha, Obra obra, Cliente cliente) {
        this.fecha = fecha;
        this.obra = obra;
        this.cliente = cliente;
    }
    
    //Getters
    public Date getFecha() {
        return fecha;
    }

    public Obra getObra() {
        return obra;
    }

    public Cliente getCliente() {
        return cliente;
    }
    
    //Setters
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setObra(Obra obra) {
        this.obra = obra;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public String toString() {
        return fecha + "\nObra: " + obra + "\nComprador: " + cliente;
    }
    
    
}
