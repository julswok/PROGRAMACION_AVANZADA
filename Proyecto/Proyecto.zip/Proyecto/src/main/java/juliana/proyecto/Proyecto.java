/*AUTORES: JUAN TORRES, JUAN FELIPE GONZALES Y JULIANA RUBIO
OBJETIVOS: -HACER UN PROGRAMA FUNCIONAL QUE PERMITA APLICAR LOS CONOCIMIENTOS APRENDIDOS EN CLASE
           -PROPORCIONAR A LOS USUARIOS UNA INTERFAZ ENTENDIBLE
FECHA: MAYO 21 DEL 2023
NOTA: EL EMAIL ES EL USUARIO, EL USUARIO DEL ADMINISTRADOR ES JOHN_CORREDOR
UN CLIENTE REGISTRADO ES MANUEL_GOMEZ
*/


package juliana.proyecto;

import java.util.Scanner;
import java.util.*;
import java.io.*;


public class Proyecto {
    
    
    private static final String ADMIN = "JOHN_CORREDOR";
    private static ControlGaleria Galeria = new ControlGaleria();
    
    public static void main(String[] args) {
        
        Scanner entrada =new Scanner (System.in);
        String emailIngresado;
        
        cargarEstado();
          
        System.out.println(" .----------------.  .----------------.  .----------------.  .----------------.\n" +
"| .--------------. || .--------------. || .--------------. || .--------------. |\n" +
"| |      __      | || |  _______     | || |  _________   | || |  _________   | |\n" +
"| |     /  \\     | || | |_   __ \\    | || | |  _   _  |  | || | |_   ___  |  | |\n" +
"| |    / /\\ \\    | || |   | |__) |   | || | |_/ | | \\_|  | || |   | |_  \\_|  | |\n" +
"| |   / ____ \\   | || |   |  __ /    | || |     | |      | || |   |  _|  _   | |\n" +
"| | _/ /    \\ \\_ | || |  _| |  \\ \\_  | || |    _| |_     | || |  _| |___/ |  | |\n" +
"| ||____|  |____|| || | |____| |___| | || |   |_____|    | || | |_________|  | |\n" +
"| |              | || |              | || |              | || |              | |\n" +
"| '--------------' || '--------------' || '--------------' || '--------------' |\n" +
" '----------------'  '----------------'  '----------------'  '----------------'");
        System.out.print("Correo electronico: ");
        emailIngresado = entrada.nextLine().toUpperCase();
        
        try {
            Cliente clienteEncontrado = iniciarSesion(emailIngresado);
            System.out.println("\nInicio de sesión exitoso. Bienvenido, " + clienteEncontrado.getNombre()+".\n");
            menuCliente(emailIngresado);
        } catch (Exception e) {
            
            if(emailIngresado.equals(ADMIN)){
                System.out.println("\nInicio de sesión exitoso. Bienvenido, JOHN.\n");
                menuAdministrador();
            }
            else{
            System.out.println("Inicio de sesión fallido. No se encontró ningún cliente con el correo electrónico ingresado.");
        }
    }
    }
    
    // Método que presenta un menú al cliente.
    public static void menuCliente(String email){
       
       Scanner entrada =new Scanner (System.in);
     
        int op1;

        do{
            System.out.println("----------------MENU-DE-CLIENTE-----------------");
            System.out.println("-> Presione 1 para ver obras disponibles");
            System.out.println("-> Presione 2 para ver las obras en su coleccion");
            System.out.println("-> Presione 3 para comprar una nueva obra");
            System.out.println("-> Presione 4 para guardar");
            System.out.println("-> Presione 0 para salir");
            System.out.print("... ");
            op1 = entrada.nextInt();
            System.out.println("---------------------------------------------");

      switch(op1){
        case 1:
            System.out.println("----------------OBRAS-DISPONIBLES----------------");
            // Primero, crear un conjunto que contendrá todas las obras compradas
            Set<Obra> obrasCompradas = new HashSet<>();

            // Recorre cada compra y agrega la obra comprada al conjunto de obrasCompradas
            for (Compras compra : Galeria.getListaCompras()) {
                obrasCompradas.add(compra.getObra());
            }

            // Ahora, crear un conjunto que contendrá todas las obras que no se han comprado
            Set<Obra> obrasSinComprar = new HashSet<>();

            // Recorre cada obra en listaObras y comprueba si la obra no ha sido comprada
            // Si la obra no ha sido comprada, entonces se añade a la lista de obrasSinComprar
            for (Obra obra : Galeria.getGestionObras().getListaObras()) {
                if (!obrasCompradas.contains(obra)) {
                    obrasSinComprar.add(obra);
                }
            }
            
            for(Obra obra : obrasSinComprar){
                System.out.println("--------------------------------------");
                System.out.println(obra.toString());
                System.out.println("--------------------------------------");
            }
                 
            break;
        case 2:

           try {
               // Muestra las obras compradas por el cliente.
               System.out.println("----------------COLECCION-OBRAS----------------");
                Set<Compras> comprasDelCliente = Galeria.getControlCliente().listarCompras(email, Galeria.getListaCompras());
                for (Compras compra : comprasDelCliente) {
                System.out.println("--------------------------------------");
                System.out.println(compra.getObra().toString());
                System.out.println("--------------------------------------");
                }
                } catch (Exception e) {
                        e.printStackTrace();
                }
            break;
            
        case 3:
            // Permite al cliente comprar una nueva obra.
            entrada.nextLine();
            String nombreObra;
            
            System.out.print("Nombre de la obra a comprar: ");
            nombreObra = entrada.nextLine();
            
            Cliente cliente = Galeria.getControlCliente().encontrarCliente(email);
            Obra obra = Galeria.getGestionObras().encontrarObra(nombreObra.toUpperCase());
            
            if(cliente != null && obra != null){
               Galeria.realizarCompra(cliente, obra);
               System.out.println("--COMPRA-EXITOSA--");
            }
            else if(cliente == null){
                System.out.println("--CLIENTE-NO-ENCONTRADO--");
            }
            else if(obra == null){
                System.out.println("--OBRA-NO-ENCONTRADA--");
            }
            break;
        case 4:
            // Guarda todo en un archivo
            guardarEstado();
            
        case 0:
            break;
           
        default:
            System.out.println("--OPCION-INVALIDA--");
            break;
        }
        }while(op1 != 0);
        }
    
    // Método que presenta un menú al administrador.
    public static void menuAdministrador() {
        
        Scanner entrada = new Scanner(System.in);

         int op1, op2;

         do {
             System.out.println("-------------MENU-DE-ADMINISTRADOR-----------");
             System.out.println("-> Presione 1 para gestionar obras y artistas");
             System.out.println("-> Presione 2 para gestionar clientes");
             System.out.println("-> Presione 3 para listar compras");
             System.out.println("-> Presione 4 para guardar");
             System.out.println("-> Presione 0 para salir");
             System.out.print("... ");
             op1 = entrada.nextInt();
             System.out.println("---------------------------------------------");

             if (op1 == 1) {
                 System.out.println("--------------GESTION-DE-OBRAS-----------");
                 System.out.println("-> Presione 1 para agregar una obra");
                 System.out.println("-> Presione 2 para eliminar una obra");
                 System.out.println("-> Presione 3 para agregar un artista");
                 System.out.println("-> Presione 4 para eliminar un artista");
                 System.out.println("-> Presione 5 para listar las obras");
                 System.out.println("-> Presione 6 para listar los artistas");
                 System.out.print("... ");
                 op2 = entrada.nextInt();
                 
                System.out.println("-----------------------------------------");
                 switch (op2) {
                     case 1:
                         //Agrega una obra a la lista de obras
                         
                         String nombreObra, tecnica, dibujo, nombreArtista;
                         int ano;
                         double precio;
                         
                         entrada.nextLine();
                         
                         System.out.print("Nombre de la obra: ");
                         nombreObra = entrada.nextLine();
                         System.out.print("Nombre del artista: ");
                         nombreArtista = entrada.nextLine();
                         System.out.print("Tecnica: ");
                         tecnica = entrada.nextLine();
                         System.out.print("Año: ");
                         ano = entrada.nextInt();
                         entrada.nextLine();
                         
                         System.out.print("Precio: ");
                         precio = entrada.nextDouble();
                         entrada.nextLine();
                         
                         
                         System.out.println("Ingresa el dibujo (puedes agregar saltos de línea):");
                         StringBuilder dibujoBuilder = new StringBuilder();

                         while (true) {
                             dibujo = entrada.nextLine();
                             if (dibujo.isEmpty()) {
                                 break;
                             }
                             dibujoBuilder.append(dibujo).append("\n");
                         }

                         dibujo = dibujoBuilder.toString();

                         try{
                            Galeria.getGestionObras().agregarObra(nombreObra.toUpperCase(), tecnica.toUpperCase(), ano, precio, nombreArtista.toUpperCase(), dibujo);
                             System.out.println("\n\n--OBRA REGISTRADA--\n");
                         }
                         catch(Exception e){
                             e.printStackTrace();
                         }
                         
                         break;
                     case 2:
                         //Elimina una obra de la lista de obras
                         
                             entrada.nextLine();
                         
                            System.out.print("Nombre de la obra a eliminar: ");
                            nombreObra = entrada.nextLine();
                            
                            try{
                                Galeria.getGestionObras().eliminarObra(nombreObra.toUpperCase());
                                System.out.println("\n\n--OBRA-ELIMINADA--\n");
                             }
                            catch(Exception e){
                             e.printStackTrace();
                             }
                            
                         break;
                     case 3:
                            //Agrega un artista a la lista de artistas
                            String biografia;
                            String nacionalidad;
                            String fecha;
                            
                            entrada.nextLine();
                            
                            System.out.print("Nombre del Artista: ");
                            nombreArtista = entrada.nextLine();
                            System.out.print("Fecha de nacimiento: ");
                            fecha = entrada.nextLine();
                            System.out.print("Nacionalidad: ");
                            nacionalidad = entrada.nextLine();
                            System.out.print("Biografia: ");
                            biografia = entrada.nextLine();
                         
                            try{
                                Galeria.getGestionObras().agregarArtista(nombreArtista.toUpperCase(), fecha, nacionalidad.toUpperCase(), biografia);
                                System.out.println("\n\n--ARTISTA-AÑADIDO--\n");
                             }
                            catch(Exception e){
                             e.printStackTrace();
                             }
                         break;
                         
                     case 4:
                         //Elimina un artista de la lista de artistas
                          entrada.nextLine();
                          
                          System.out.print("Nombre del artista a eliminar: ");
                          nombreArtista =  entrada.nextLine();
                          
                          
                          try{
                                Galeria.getGestionObras().eliminarArtista(nombreArtista.toUpperCase());
                                System.out.println("\n\n--ARTISTA-ELIMINADO--\n");
                             }
                            catch(Exception e){
                             e.printStackTrace();
                             }
                          
                          break;
                     case 5:
                         //Imprime todas las obras
                         imprimirObras(Galeria.getGestionObras().getListaObras());
                         break;
                         
                     case 6:
                         //Imprime todos los artistas
                         imprimirArtistas(Galeria.getGestionObras().getListaArtistas());
                         break;
                         
                     default:
                         System.out.println("--OPCION-INVALIDA--");
                         break;
                 }
             }
             else if (op1 == 2) {
                 System.out.println("--------------GESTION-DE-CLIENTES------------");
                 System.out.println("-> Presione 1 para agregar un cliente");
                 System.out.println("-> Presione 2 para eliminar un cliente");
                 System.out.println("-> Presione 3 para listar clientes");
                 System.out.print("... ");

                 op2 = entrada.nextInt();
                 System.out.println("---------------------------------------------");
                 switch (op2) {
                     case 1:
                         //Agrega un cliente
                         entrada.nextLine();
                         
                         String nombre, direccion, email;
                         
                         System.out.print("Nombre: ");
                         nombre = entrada.nextLine();
                         System.out.print("Direccion: ");
                         direccion = entrada.nextLine();
                         System.out.print("Email: ");
                         email = entrada.nextLine();
                        
                               
                          try{
                                Galeria.getControlCliente().agregarCliente(nombre.toUpperCase(), direccion.toUpperCase(), email.toUpperCase());
                                System.out.println("\n\n--CLIENTE-REGISTRADO--\n");
                             }
                            catch(Exception e){
                             e.printStackTrace();
                             }
                                 
                         break;
                     case 2:
                           //Elimina un cliente
                           entrada.nextLine();
                           
                           System.out.print("Email del cliente a eliminar: ");
                           email = entrada.nextLine();
                           
                           try{
                                Galeria.getControlCliente().eliminarCliente(email.toUpperCase());
                                System.out.println("\n\n--CLIENTE-ELIMINADO--\n");
                             }
                            catch(Exception e){
                             e.printStackTrace();
                             }
                         
                         break;
                     case 3:
                            //Imprime todos los clientes
                            imprimirClientes(Galeria.getControlCliente().getListaClientes());
                         break;
                     default:
                         System.out.println("---OPCION-INVALIDA---");
                         break;
                 }
             }
             else if(op1 == 3){
                 //Imprime todas las compras
                 int i = 0;
                 for(Compras compra : Galeria.getListaCompras()){
                      i++;
                      System.out.println(i+". " + compra.toString()+"\n");
                 }
             }
             else if(op1 == 4){
                 //Guarda en un archivo
                 guardarEstado();
             }
         } while (op1 != 0);
     }
    
    public static void imprimirClientes(Set<Cliente> listaClientes) {
        int i = 0;
        for (Cliente cliente : listaClientes) {
            i++;
            System.out.println(i+". "+cliente.toString());
        }
    }
    public static void imprimirArtistas(Set<Artista> listaArtistas) {
        int i = 0;
        for (Artista artista : listaArtistas) {
            i++;
            System.out.println(i+". "+ artista.toString());
        }
    }
    public static void imprimirObras(Set<Obra> listaObras) {
        
        for (Obra obra : listaObras) {
            System.out.println("--------------------------------------");
            System.out.println(obra.toString());
            System.out.println("--------------------------------------");
        }
    }
   
 public static void guardarEstado() {
     //Metodo para serializar todas las listas
    try {
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("estado.ser"));
        salida.writeObject(Galeria.getGestionObras().getListaArtistas());
        salida.writeObject(Galeria.getGestionObras().getListaObras());
        salida.writeObject(Galeria.getListaCompras());
        salida.writeObject(Galeria.getControlCliente().getListaClientes());
        salida.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

public static void cargarEstado() {
    //Metodo para deserializar todas las listas
    try {
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("estado.ser"));
        
        Set<Artista> listaArtistas = (Set<Artista>) entrada.readObject();
        Set<Obra> listaObras = (Set<Obra>) entrada.readObject();
        Set<Compras> listaCompras = (Set<Compras>) entrada.readObject();
        Set<Cliente> listaClientes = (Set<Cliente>) entrada.readObject();
        
        Galeria.getGestionObras().setListaArtistas(listaArtistas);
        Galeria.getGestionObras().setListaObras(listaObras);
        Galeria.setListaCompras(listaCompras);
        Galeria.getControlCliente().setListaClientes(listaClientes);
        entrada.close();
    } catch (IOException | ClassNotFoundException e) {
        e.printStackTrace();
    }
}

public static Cliente iniciarSesion(String email) throws Exception {
        //Metodo para iniciar sesion
        for (Cliente cliente : Galeria.getControlCliente().getListaClientes()) {
            if (cliente.getEmail().equals(email)) {
                return cliente; // Se encontró el cliente, se devuelve el objeto Cliente
            }
        }

        throw new Exception("--EMAIL-NO-ENCONTRADO--"); // No se encontró ningún cliente con el correo electrónico ingresado
    }
}


